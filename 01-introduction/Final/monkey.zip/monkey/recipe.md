#Kitty's Monkey Bread

##Ingredients

- Sourdough Starter
- All-Purpose Flour
- Whole Wheat Flour
- Bread Flour
- Water
- Salt

##Equipment

- 2qt Dutch Oven
- Medium Bowl
- Smaller Bowl
- 2 Dish Cloths
- Lame or Sharp Knife
- Squirty Water Bottle

##Steps

1. Before making bread, feed your starter.
    * Discard most of your current starter
    * Feed it 25g whole wheat flour and 25g filtered water
    * Loosely replace lid and let sit in a warm place until doubled in size and very bubbly (~ 7-10 hours)

1. When the starter is ready: in a medium bowl, combine 37g starter, 7g salt, and 246g filtered water until salt just dissolves.

1. Add 41g all-purpose flour, 123g whole wheat flour, and 164g bread flour. Stir until a shaggy dough forms -- no dry bits at the bottom.

1. Cover with a clean, damp dish cloth and let sit 1 hour in a warm place. Feed starter again as in step 1 and set next to dough.

1. When the hour is up, uncover dough and perform stretch + folds. Recover with the dish cloth, and return to the warm place and leave for 1 hour. Repeat twice more, doing 3 sets of stretch + folds in total.
![diagrm of how to stretch + fold](images/folding-diagram.jpg)

1. Let dough sit unbothered for about 9 hours. Starter that you fed in step 4 should be large and very bubbly. Generally, dough is ready 11 - 13 hours after step 3.

1. Lightly flour workspace. Coax dough out of bowl onto workspace. Do stretch + folds until dough becomes a tight ball. Flip dough seam-side down. Using your hands, turn the dough until ball is round an dneat.

1. Get a deep bowl and line with a dry dish cloth (clean). Sprinkle with flour. Sprinkle top of dough with flour and gently plop dough seam-side up into bowl. Pinch together edges of ball into the center to make extra tight. Sprinkle with flour, fold over dish cloth, and put into refrigerator.

1. After 30 minutes, place empty Dutch Oven into the oven and preheat to 499F.

1. When over is ready, remove dough from fridge. Plop seam side down on baking papaer. Use knife or bread lame to score cross into top of dough. Then, carefully remove Dutch Oven from oven and place dough inside, cross shape up. Spray generously with water, replace lid, and put in oven for 10 minutes.

1. Lower heat to 436F and bake for 20 minutes.

1. Say a prayer, remove Dutch Oven lid, and bake an additional 10 - 15 minutes until loaf is golden brown.

1. Remove from oven. Remove loaf from Dutch Oven and let cool on a wire rack for at least 10 minutes (preferably a few hours) before eating.

![loaf on 10 dec 2023](images/loaf.jpeg)


Notes for 10 Dec 2023:

Change the flour ratios. Also added a pinch of yeast to try to make the process go faster. Seemed to cut the 9 hour rise time about in half.
