#README

- main branch is the initial recipe and large loaves once we create the small loaf branch
- two tags for the recipes
- after small loaf branch was created showed fixing some typos in the main branch and then merging that into small loaf branch
- demonstration with merge/pr could be to convert either small or large to Imperial and either merge, or maybe just leave it as its own branch
- used merge commits so that Tower would make a pretty graph of the history
